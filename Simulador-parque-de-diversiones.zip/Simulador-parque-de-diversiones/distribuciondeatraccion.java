// Excepción personalizada
class NoHayAtraccionesDisponiblesException extends Exception {
    public NoHayAtraccionesDisponiblesException(String mensaje) {
        super(mensaje);
    }
}

// Método para reubicar visitantes
public void realizarMantenimiento() {
    estado = "mantenimiento";
    try {
        reubicarVisitantes();
    } catch (NoHayAtraccionesDisponiblesException e) {
        System.out.println("Error al reubicar visitantes: " + e.getMessage());
        // Aquí se podría notificar a los visitantes o registrar el error
    }
}

// Método que intenta reubicar a los visitantes
private void reubicarVisitantes() throws NoHayAtraccionesDisponiblesException {
    List<Atraccion> atraccionesDisponibles = obtenerAtraccionesDisponibles();
    
    if (atraccionesDisponibles.isEmpty()) {
        throw new NoHayAtraccionesDisponiblesException("No hay atracciones disponibles para reubicar a los visitantes.");
    }
    
    // Lógica para reubicar a los visitantes a las atracciones disponibles
    for (Visitante visitante : listaVisitantes) {
        for (Atraccion atraccion : atraccionesDisponibles) {
            if (atraccion.esAccesible(visitante)) {
                // Reubicar al visitante a esta atracción
                System.out.println("Visitante " + visitante.nombre + " reubicado a " + atraccion.nombre);
                break; // Salir del bucle una vez que se reubica al visitante
            }
        }
    }
}

// Método que obtiene las atracciones disponibles
private List<Atraccion> obtenerAtraccionesDisponibles() {
    // Lógica para obtener las atracciones que están operativas y tienen capacidad
    List<Atraccion> disponibles = new ArrayList<>();
    for (Atraccion atraccion : listaAtracciones) {
        if (atraccion.estado.equals("operativa") && atraccion.capacidad > 0) {
            disponibles.add(atraccion);
        }
    }
    return disponibles;
}
